import { GoogleAuth } from "google-auth-library"
import { google } from "googleapis"

// Configuración de autenticación
const auth = new GoogleAuth({
  credentials: JSON.parse(process.env.GOOGLE_SERVICE_ACCOUNT_KEY || "{}"),
  scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
})

const sheets = google.sheets({ version: "v4", auth })
const SPREADSHEET_ID = "1Vdjic6VsYDF7uHQ4g020wkTXQ35GJAqOAQEMhVtOVSg"

export async function getSheetData(sheetName: string) {
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SPREADSHEET_ID,
      range: `${sheetName}!A:Z`, // Obtener todas las columnas
    })

    const rows = response.data.values
    if (!rows || rows.length === 0) {
      console.log(`No data found in sheet: ${sheetName}`)
      return []
    }

    if (sheetName === "anuncios") {
      // Anuncios desde fila 10: C10=checkbox, D10=título, E10=texto, F10=imagen
      if (rows.length >= 10) {
        const anuncioRow = rows[9] // Fila 10 (índice 9)
        const activo = anuncioRow[2] === "TRUE" || anuncioRow[2] === "true" || anuncioRow[2] === true

        if (activo && anuncioRow[3]) {
          return [
            {
              active: true,
              title: anuncioRow[3] || "Anuncio",
              message: anuncioRow[4] || "",
              buttonText: "Más información",
              buttonLink: "/contacto",
              imagen: anuncioRow[5] || null, // Imagen opcional
            },
          ]
        }
      }
      return []
    }

    if (sheetName === "noticias") {
      // Noticias: cada columna es una noticia
      // Fila 1: títulos, Fila 2: textos, Fila 3: imágenes, Fila 4: checkboxes
      const noticias = []

      if (rows.length >= 4) {
        const titulos = rows[0] || []
        const textos = rows[1] || []
        const imagenes = rows[2] || []
        const checkboxes = rows[3] || []

        // Iterar por cada columna (cada noticia)
        for (let col = 0; col < titulos.length; col++) {
          const titulo = titulos[col]
          const texto = textos[col]
          const imagen = imagenes[col]
          const activo = checkboxes[col] === "TRUE" || checkboxes[col] === "true" || checkboxes[col] === true

          // Solo agregar si está activo y tiene título
          if (activo && titulo && titulo.trim() !== "") {
            noticias.push({
              id: (col + 1).toString(),
              titulo: titulo,
              resumen: texto || "",
              fecha: new Date().toISOString().split("T")[0], // Fecha actual
              imagen: imagen || "/placeholder.svg?height=300&width=500",
              contenido: texto || "",
              categoria: "Institucional",
            })
          }
        }
      }

      return noticias
    }

    return []
  } catch (error) {
    console.error(`Error fetching sheet data for ${sheetName}:`, error)
    return []
  }
}
