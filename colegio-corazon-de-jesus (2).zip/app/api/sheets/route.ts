import { NextResponse } from "next/server"

// Esta es una implementación simulada. En producción, conectarías con Google Sheets API
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const sheet = searchParams.get("sheet")

  // Simulamos datos para demostración
  if (sheet === "anuncios") {
    return NextResponse.json([
      {
        active: true,
        title: "¡Inscripciones Abiertas!",
        message:
          "Están abiertas las inscripciones para el ciclo lectivo 2025. No pierdas la oportunidad de formar parte de nuestra comunidad educativa.",
        buttonText: "Inscribirme ahora",
        buttonLink: "/inscripciones",
      },
    ])
  }

  if (sheet === "noticias") {
    return NextResponse.json([
      {
        id: "1",
        titulo: "Inscripciones abiertas para el ciclo lectivo 2025",
        resumen:
          "Ya están abiertas las inscripciones para todos los niveles educativos. Consulta requisitos y fechas importantes.",
        fecha: "2024-05-15",
        imagen: "/placeholder.svg?height=300&width=500",
        contenido:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      },
      {
        id: "2",
        titulo: "Celebración del Día de Santa Joaquina",
        resumen: "Nuestra comunidad educativa celebró con alegría la festividad de Santa Joaquina de Vedruna.",
        fecha: "2024-05-22",
        imagen: "/placeholder.svg?height=300&width=500",
        contenido:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      },
      {
        id: "3",
        titulo: "Proyecto solidario: Ayudando a nuestra comunidad",
        resumen: "Los alumnos de secundaria participaron en una jornada solidaria en el barrio de Balvanera.",
        fecha: "2024-04-28",
        imagen: "/placeholder.svg?height=300&width=500",
        contenido:
          "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
      },
    ])
  }

  return NextResponse.json([])
}
