import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { CalendarIcon, ArrowLeft, Share2, Bookmark } from "lucide-react"

interface NoticiasPageProps {
  params: {
    id: string
  }
}

export async function generateMetadata({ params }: NoticiasPageProps) {
  // En un entorno real, obtendríamos los datos de la noticia específica
  // Para este ejemplo, usamos datos estáticos
  return {
    title: `Noticia | Colegio Corazón de Jesús`,
    description: "Detalles de la noticia del Colegio Corazón de Jesús en Balvanera, Buenos Aires.",
  }
}

export default async function NoticiaDetallePage({ params }: NoticiasPageProps) {
  const { id } = params

  // En un entorno real, obtendríamos los datos de la noticia específica
  // Para este ejemplo, usamos datos estáticos
  const noticia = {
    id,
    titulo: "Inscripciones abiertas para el ciclo lectivo 2025",
    resumen:
      "Ya están abiertas las inscripciones para todos los niveles educativos. Consulta requisitos y fechas importantes.",
    fecha: "2024-05-15",
    imagen: "/placeholder.svg?height=600&width=1200",
    contenido: `
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
      
      <p>Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      
      <h3>Requisitos para la inscripción</h3>
      
      <ul>
        <li>Partida de nacimiento (original y fotocopia)</li>
        <li>DNI del alumno (original y fotocopia)</li>
        <li>DNI de los padres (original y fotocopia)</li>
        <li>Certificado de vacunación actualizado</li>
        <li>Certificado de buena salud</li>
        <li>Libreta de calificaciones o certificado de alumno regular (para alumnos que provienen de otras instituciones)</li>
      </ul>
      
      <h3>Fechas importantes</h3>
      
      <p>Las inscripciones estarán abiertas desde el 1 de junio hasta el 30 de octubre de 2024, o hasta agotar vacantes. Te recomendamos no dejar para último momento este trámite importante.</p>
      
      <p>Para más información, no dudes en contactarnos a través de nuestro formulario de contacto o llamando al (011) 4951-5123 en el horario de 8:00 a 16:30 hs.</p>
    `,
    categoria: "Institucional",
    autor: "Equipo Directivo",
  }

  // Noticias relacionadas
  const noticiasRelacionadas = [
    {
      id: "2",
      titulo: "Celebración del Día de Santa Joaquina",
      fecha: "2024-05-22",
      imagen: "/placeholder.svg?height=200&width=300",
      categoria: "Pastoral",
    },
    {
      id: "3",
      titulo: "Proyecto solidario: Ayudando a nuestra comunidad",
      fecha: "2024-04-28",
      imagen: "/placeholder.svg?height=200&width=300",
      categoria: "Secundaria",
    },
    {
      id: "4",
      titulo: "Feria de Ciencias 2024",
      fecha: "2024-04-15",
      imagen: "/placeholder.svg?height=200&width=300",
      categoria: "Académico",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <Button asChild variant="ghost" className="mb-4">
            <Link href="/noticias" className="flex items-center text-[#0a2d8f]">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Volver a noticias
            </Link>
          </Button>

          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center text-sm text-gray-500">
              <CalendarIcon className="mr-1 h-4 w-4" />
              <time dateTime={noticia.fecha}>
                {new Date(noticia.fecha).toLocaleDateString("es-ES", {
                  day: "numeric",
                  month: "long",
                  year: "numeric",
                })}
              </time>
              {noticia.categoria && (
                <>
                  <span className="mx-2">•</span>
                  <span className="bg-[#0a2d8f] text-white text-xs px-2 py-1 rounded">{noticia.categoria}</span>
                </>
              )}
            </div>
            <div className="flex space-x-2">
              <Button variant="ghost" size="icon" title="Compartir">
                <Share2 className="h-4 w-4" />
                <span className="sr-only">Compartir</span>
              </Button>
              <Button variant="ghost" size="icon" title="Guardar">
                <Bookmark className="h-4 w-4" />
                <span className="sr-only">Guardar</span>
              </Button>
            </div>
          </div>

          <h1 className="text-3xl font-bold text-[#0a2d8f] mb-4">{noticia.titulo}</h1>
          <p className="text-xl text-gray-600 mb-6">{noticia.resumen}</p>

          <div className="relative rounded-lg overflow-hidden mb-8 h-80">
            <Image src={noticia.imagen || "/placeholder.svg"} alt={noticia.titulo} fill className="object-cover" />
          </div>

          <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: noticia.contenido }}></div>

          {noticia.autor && (
            <div className="mt-8 pt-4 border-t border-gray-200">
              <p className="text-sm text-gray-500">
                Publicado por: <span className="font-medium">{noticia.autor}</span>
              </p>
            </div>
          )}
        </div>

        <div className="mt-12 pt-8 border-t border-gray-200">
          <h2 className="text-2xl font-bold text-[#0a2d8f] mb-6">Noticias relacionadas</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {noticiasRelacionadas.map((noticia) => (
              <Link key={noticia.id} href={`/noticias/${noticia.id}`} className="group">
                <div className="relative h-40 rounded-lg overflow-hidden mb-2">
                  <Image
                    src={noticia.imagen || "/placeholder.svg"}
                    alt={noticia.titulo}
                    fill
                    className="object-cover"
                  />
                  {noticia.categoria && (
                    <div className="absolute top-2 right-2">
                      <span className="bg-[#0a2d8f] text-white text-xs px-2 py-1 rounded">{noticia.categoria}</span>
                    </div>
                  )}
                </div>
                <h3 className="font-medium text-[#0a2d8f] group-hover:underline">{noticia.titulo}</h3>
                <div className="flex items-center text-xs text-gray-500 mt-1">
                  <CalendarIcon className="mr-1 h-3 w-3" />
                  <time dateTime={noticia.fecha}>
                    {new Date(noticia.fecha).toLocaleDateString("es-ES", {
                      day: "numeric",
                      month: "long",
                      year: "numeric",
                    })}
                  </time>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
